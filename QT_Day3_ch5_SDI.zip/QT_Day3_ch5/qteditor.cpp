#include "qteditor.h"
#include <QTextEdit>
#include <QLabel>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QStyle>
#include <QKeySequence>
#include <QApplication>
#include <QToolBar>
#include <QFontComboBox>
#include <QDoubleSpinBox>
#include <QStatusBar>
#include <QDockWidget>
qteditor::qteditor(QWidget *parent)
    : QMainWindow(parent)
{
//�ٸ� �������� ��� dock
#if !dockwidget
    QWidget *w = new QWidget(this);
    QLabel *label=new QLabel("Dock Widget",w);
    label->setAlignment(Qt::AlignCenter);
    QDockWidget *dock=new QDockWidget("Dock Widget",this);
    dock->setAllowedAreas(Qt::LeftDockWidgetArea|Qt::RightDockWidgetArea);
    addDockWidget(Qt::RightDockWidgetArea,dock);
    dock->setWidget(w);
#endif
#if !textedit
    textEdit=new QTextEdit(this);
    setCentralWidget(textEdit);
#endif

#if !menubar
    QMenuBar* menuBar=new QMenuBar(this);
    setMenuBar(menuBar);
#endif
#if action_single
    QIcon icon=style()->standardIcon(QStyle::SP_DialogSaveButton);
    QAction *newAct=new QAction(icon,"&New",this);
    //QAction *newAct=new QAction(QIcon("new.png"),"&New",this);
    newAct->setShortcut(tr("Ctrl+N"));
    newAct->setStatusTip(tr("make new file"));
    connect(newAct,SIGNAL(triggered()),SLOT(newFile()));
#endif
#if !actionusing_template
    //QAction *fileAct=makeAction(":/images/new.png","&New",tr("Ctrl+N"),tr("make new file"),this,SLOT(newFile()));
    QAction *fileAct=makeAction(style()->standardIcon(QStyle::SP_DialogSaveButton),"&New",tr("Ctrl+N"),tr("make new file"),this,SLOT(newFile()));
    QAction *openAct=makeAction(":/images/open.png","&Open",tr("Ctrl+O"),tr("open file"),this,SLOT(openFile()));
    QAction *saveAct=makeAction(":/images/save.png","&Save",tr("Ctrl+S"),tr("save file"),this,SLOT(saveFile()));
    QAction *saveasAct=makeAction(":/images/saveas.png","&Save As",tr("Ctrl+A"),tr("save as other file"),this,SLOT(saveasFile()));
    QAction *printAct=makeAction(":/images/print.png","&Print",tr("Ctrl+P"),tr("print file"),this,SLOT(printFile()));
    //QAction *quitAct=makeAction(":/images/quit.png","&Quit",tr("Ctrl+Q"),tr("quit file"),qApp,SLOT(quit()));
    QAction *quitAct=makeAction(":/images/quit.png","&Quit",tr("Ctrl+Q"),tr("quit file"),[=](){qApp->quit();});
#endif
#if !menu
    QMenu *fileMenu=menuBar->addMenu("&file");
    fileMenu->addAction(fileAct);
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);
    fileMenu->addAction(saveasAct);
    fileMenu->addSeparator();
    fileMenu->addAction(printAct);
    fileMenu->addSeparator();
    fileMenu->addAction(quitAct);
#endif
#if !actioneditusing_tem
    QAction *undoAct=makeAction(":/images/undo.png","&Undo",tr("Ctrl+Z"),tr("undo"),textEdit,SLOT(undo()));
    QAction *redoAct=makeAction(":/images/redo.png","&redo",tr("Ctrl+R"),tr("redo"),textEdit,SLOT(redo()));
    QAction *copyAct=makeAction(":/images/copy.png","&copy",tr("Ctrl+C"),tr("copy"),textEdit,SLOT(copy()));
    QAction *cutAct=makeAction(":/images/cut.png","&cut",tr("Ctrl+X"),tr("cut"),textEdit,SLOT(cut()));
    QAction *pasteAct=makeAction(":/images/paste.png","&paste",tr("Ctrl+V"),tr("paste"),textEdit,SLOT(paste()));
    QAction *zoomInAct=makeAction(":/images/zoomIn.png","&zoomIn",tr("Ctrl+I"),tr("zoomIn"),textEdit,SLOT(zoomIn()));
    QAction *zoomOutAct=makeAction(":/images/zoomOut.png","&zoomOut",tr("Ctrl+Alt+I"),tr("zoomOut"),textEdit,SLOT(zoomOut()));
#endif
#if !editmenu
    QMenu*editMenu=menuBar->addMenu("&edit");
    editMenu->addAction(undoAct);
    editMenu->addAction(redoAct);
    editMenu->addSeparator();
    editMenu->addAction(copyAct);
    editMenu->addAction(cutAct);
    editMenu->addAction(pasteAct);
    editMenu->addSeparator();
    editMenu->addAction(zoomInAct);
    editMenu->addAction(zoomOutAct);
#endif
#if !formatMenu+action
    QMenu*formatMenu=menuBar->addMenu("&Format");
    QMenu*alignMenu=formatMenu->addMenu("&Align");
    //page 40 triggered��ü�� �Ѱ��ִ� ���ڰ� ���⶧���� Qt::AlignCenter�� �Ѱ��� ����� ��� align����� ������ �� ����.
    //SIGNAL SLOT ����Ϸ��� ����� slot�ʿ�.
    QAction *fontAct=makeAction(":/images/font.png","&font",tr("Ctrl+F"),tr("Font"),[=]{textEdit->setCurrentFont(QFont("Arial", 12));});//slot X
    QAction *colorAct=makeAction(":/images/color.png","&color",tr("Ctrl+G"),tr("Color"),[=]{textEdit->setTextColor(QColor("Blue"));});//slot X
    QAction *leftAct=makeAction(":/images/left.png","&Left",tr("Ctrl+1"),tr("Left"),[=]{textEdit->setAlignment(Qt::AlignLeft);});
    QAction *centerAct=makeAction(":/images/center.png","&Center",tr("Ctrl+2"),tr("Center"),[=]{textEdit->setAlignment(Qt::AlignCenter);});
    QAction *rightAct=makeAction(":/images/right.png","&Right",tr("Ctrl+3"),tr("Right"),[=]{textEdit->setAlignment(Qt::AlignRight);});
    QAction *justifyAct=makeAction(":/images/justify.png","&Justify",tr("Ctrl+4"),tr("justify"),[=]{textEdit->setAlignment(Qt::AlignJustify);});
    alignMenu->addAction(fontAct);
    alignMenu->addAction(colorAct);
    alignMenu->addAction(leftAct);
    alignMenu->addAction(centerAct);
    alignMenu->addAction(rightAct);
    alignMenu->addAction(justifyAct);
#endif
#if !toolbar+windowmenu
    QToolBar* fileToolBar=addToolBar("&file");
    fileToolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    fileToolBar->addAction(fileAct);
    fileToolBar->addSeparator();
    fileToolBar->addAction(quitAct);

    QMenu *windowMenu=menuBar->addMenu("&Window");
    QMenu *toolbarMenu=windowMenu->addMenu("&Toolbar");
    toolbarMenu->addAction(fileToolBar->toggleViewAction());

    QFontComboBox *fontComboBox=new QFontComboBox(this);
    connect(fontComboBox,SIGNAL(currentFontChanged(QFont)),textEdit,SLOT(setCurrentFont(QFont)));
    QDoubleSpinBox *sizeSpinBox=new QDoubleSpinBox(this);
    connect(sizeSpinBox,SIGNAL(valueChanged(double)),textEdit,SLOT(setFontPointSize(qreal)));
    addToolBarBreak();
    QToolBar *formatToolBar= addToolBar("&Format");
    formatToolBar->addSeparator();
    formatToolBar->addWidget(fontComboBox);
    formatToolBar->addWidget(sizeSpinBox);
#endif
#if !statusBar
    QStatusBar* statusbar=statusBar();
    QLabel * statusLabel = new QLabel("Qt Editor",statusbar);
    statusLabel->setObjectName("Status name");
    statusbar->addPermanentWidget(statusLabel);
    statusbar->showMessage("started",1500);

#endif
#if !dockshow
    toolbarMenu->addAction(dock->toggleViewAction());
#endif

}
void qteditor::newFile(){
    qDebug("Make new File");
}
void qteditor::openFile(){
    qDebug("open File");
}
void qteditor::saveFile(){
    qDebug("save File");
}
void qteditor::saveasFile(){
    qDebug("save as File");
}
void qteditor::printFile(){
    qDebug("print File");
}
// template<typename T>
// QAction *qteditor::makeAction(QString icon, QString text,T shortCut,QString toolTip,QObject*recv,const char* slot){
//     QAction *newAct=new QAction(QIcon(icon),text,this);
//     newAct->setShortcut(shortCut);
//     newAct->setStatusTip(toolTip);
//     connect(newAct,SIGNAL(triggered()),recv,slot);
//     return newAct;
// }
template <typename T,typename R>
QAction* qteditor::makeAction(R icon, QString text,T shortCut,QString toolTip,QObject*recv,const char* slot){
    R icon2=icon;
    QAction *newAct=new QAction(QIcon(icon2),text,this);
    newAct->setShortcut(QString(shortCut));
    newAct->setStatusTip(toolTip);
    connect(newAct,SIGNAL(triggered()),recv,slot);
    return newAct;
}
template<>
QAction *qteditor::makeAction(QString icon, QString text,const char* shortCut,QString toolTip,QObject*recv,const char* slot){
    QAction *newAct=new QAction(QIcon(icon),text,this);
    newAct->setShortcut(QString(shortCut));
    newAct->setStatusTip(toolTip);
    connect(newAct,SIGNAL(triggered()),recv,slot);
    return newAct;
}
template <typename T,typename Functor>
QAction* qteditor::makeAction(QString icon, QString text,T shortCut,QString toolTip,Functor lambda){
    QAction *newAct=new QAction(QIcon(icon),text,this);
    QKeySequence keySequence(shortCut);
    newAct->setShortcut(keySequence);
    newAct->setStatusTip(toolTip);
    connect(newAct,&QAction::triggered,this,lambda);
    return newAct;
}
qteditor::~qteditor() {

}
